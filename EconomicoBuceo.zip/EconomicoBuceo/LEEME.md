# Económico Buceo: cómo sacar el APK

Este proyecto es la app "Económico del Centro de Buceo" empaquetada para Android. Funciona sin internet, guarda los datos en el teléfono y exporta a Excel (.xlsx).

## Opción 1: compilarlo gratis en GitHub (no hay que instalar nada)

1. Crea una cuenta en github.com, si no tienes.
2. Crea un repositorio nuevo (puede ser privado), por ejemplo `economico-buceo`.
3. Pulsa **Add file → Upload files** y sube **todo el contenido** de esta carpeta. Incluye la carpeta oculta `.github`. Si el navegador no la sube, créala a mano: **Add file → Create new file**, con el nombre `.github/workflows/compilar-apk.yml`, y pega dentro el contenido de ese archivo.
4. Entra en la pestaña **Actions**. La compilación empieza sola y tarda unos 5 minutos.
5. Cuando termine con la marca verde, abre la ejecución y descarga **Economico-Buceo-APK**. Es un .zip que trae dentro el `.apk`.

## Opción 2: con Android Studio

1. Abre esta carpeta con **File → Open**.
2. Espera a que termine de descargar lo necesario. Hace falta internet la primera vez.
3. Pulsa **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. El APK queda en `app/build/outputs/apk/`.

## Instalar en el teléfono

1. Pasa el `.apk` al teléfono por WhatsApp, Telegram o cable.
2. Ábrelo y permite **instalar apps de origen desconocido** cuando el teléfono lo pida.

## Importante sobre los datos

- Los datos viven solo dentro de la app. Si la desinstalas o borras sus datos, se pierden.
- Haz una copia de seguridad cada semana desde **Calendario → Tus datos → Guardar copia de seguridad**.
- Guarda esa copia fuera del teléfono, por ejemplo en tu correo o en la computadora.
- Para pasar los datos a otro teléfono, usa **Restaurar copia** con ese archivo.
- La pestaña **Consultar** (preguntas al económico) solo funciona en la versión de Claude, no en el APK.
